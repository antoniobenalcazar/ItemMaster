var urlWS = "";
$(document).ready(function(){
   urlWS = "http://localhost/ItemMaster/server/";
   leer(0);
   crearTablaKendo();
});

function crearTablaKendo(){
    $("#tablaKendo").kendoGrid({
        dataSource: {
           pageSize: 5,
           transport: {
              read: {
                    url: urlWS+"/Roll/leer",
                    dataType: "json"
              }
           }
        },
        columns: [
           {field: "IdRoll", title: "Id de Roll"},
           {field: "nombreRoll", title: "Nombre de Roll"},
           {field: "TipoRoll", title: "Tipo De Roll"},
	   {field: "NivelRoll", title: "Nivel de Roll"},
        ],
        pageable:   true,
        selectable:   true,
        filterable: {
            mode: "row",
            extra: false,
            operators: {
               String: {
                  contains: "Contains"
               }
            }
        },
        change: itemSeleccionado
    });
}

function itemSeleccionado(){
   var datos = $("#tablaKendo").data("kendoGrid");
   var selectedItem = datos.dataItem(datos.select());
   alert('La Cédula de ' + selectedItem.nombre1 + ' ' + selectedItem.nombre2 + ' ' + selectedItem.apellido1 + ' ' + selectedItem.apellido2 + ' es: '+ selectedItem.identificacion);
}

function limpiar(){
    document.getElementById("id").value = "";
    document.getElementById("descripcion").value = "";
}

function leer(id){
    if(id==0){
        urltorequest = urlWS +"Roll/leer";
    }else{
        urltorequest = urlWS +"Roll/leer?id="+id;
    }
    $.ajax({
        type: "get",
        url: urltorequest,
        async:true,
        success:  function (respuesta) {
           toshow = JSON.parse(respuesta);
           cabeceraTabla = "<table class=\"table table-condensed\"><thead><tr><th>id</th><th>Descripcion</th></tr></thead><tbody>";
           pieTabla = "</tbody></table>";
           contenidoTabla = "";
           $(toshow).each(function(key,value){
                contenidoTabla=contenidoTabla+"<tr><td>"+value.id+"</td><td>"+value.descripcion+"</td></tr>";
           });
        }
    });
    limpiar();
}

function borrar(){
    id = document.getElementById("id").value;
    urltorequest = urlWS +"Roll/borrar?id="+id;
    $.ajax({
        type: "get",
        url: urltorequest,
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al borrar el Roll " + id + ".");
            }else{
                alert("Roll borrado: " + id + ".");
            }
        }
    });
    leer(0);
}

function crear(){
    id = document.getElementById("id").value;
    descripcion = document.getElementById("descripcion").value;
    urltorequest = urlWS +"Roll/crear";
    $.ajax({
        type: "post",
        url: urltorequest,
        data:JSON.stringify({id: id, descripcion: descripcion}),
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al crear el Roll");
            }else{
                alert("Roll creado.");
            }
        }
    });
    leer(0);
}

function actualizar(){
    id = document.getElementById("id").value;
    descripcion = document.getElementById("descripcion").value;
    urltorequest = urlWS +"genero/actualizar";
    $.ajax({
        type: "post",
        url: urltorequest,
        data:JSON.stringify({id: id, descripcion: descripcion}),
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al actualizar el registro");
            }else{
                alert("Registro actualizado.");
            }
        }
    });
    leer(0);
}
