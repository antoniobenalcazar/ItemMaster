var urlWS = "";
$(document).ready(function(){
   urlWS = "http://localhost/ItemMaster/server/";
   leer();
   crearTablaKendo();
});

function crearTablaKendo(){
    $("#tablaKendo").kendoGrid({
        dataSource: {
           pageSize: 5,
           transport: {
              read: {
                    url: urlWS+"Roll/leer",
                    dataType: "json"
              }
           }
        },
        columns: [
           {field: "IdRoll", title: "Id de Roll"},
           {field: "nombreRoll", title: "Nombre de Roll"},
           {field: "tipoRoll", title: "Tipo De Roll"},
	       {field: "nivelRoll", title: "Nivel de Roll"},
        ],
        pageable:   true,
        selectable:   true,
        filterable: {
            mode: "row",
            extra: false,
            operators: {
               String: {
                  contains: "Contains"
               }
            }
        },
        change: itemSeleccionado
    });
}

function itemSeleccionado(){
   var datos = $("#tablaKendo").data("kendoGrid");
   var selectedItem = datos.dataItem(datos.select());
   alert('Usted selecciono el roll'+'=' + selectedItem.nombreRoll);
}

function limpiar(){
    document.getElementById("idRoll").value = "";
    document.getElementById("nombreRoll").value = "";
    document.getElementById("tipoRoll").value = "";
    document.getElementById("nivelRoll").value = "";
}

function leer(id){
    if(id==0){
        urltorequest = urlWS +"Roll/leer";
    }else{
        urltorequest = urlWS +"Roll/leer?id="+id;
    }
    $.ajax({
        type: "get",
        url: urltorequest,
        async:true,
        success:  function (respuesta) {
           toshow = JSON.parse(respuesta);
           cabeceraTabla = "<table class=\"table table-condensed\"><thead><tr><th>IdRoll</th><th>nombreRoll</th><th>tipoRoll</th><th>nivelRoll</th></tr></thead><tbody>";
           pieTabla = "</tbody></table>";
           contenidoTabla = "";
           $(toshow).each(function(key,value){
                contenidoTabla=contenidoTabla+"<tr><td>"+value.IdRoll+"</td><td>"+value.nombreRoll+"</td><td>"+value.tipoRoll+"</td><td>"+value.nivelRoll+"</td></tr>";
           });
        }
    });
    limpiar();
}
function borrar(){
    id = document.getElementById("IdRoll").value;
    urltorequest = urlWS +"Roll/borrar?id="+id;
    $.ajax({
        type: "get",
        url: urltorequest,
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al borrar el Roll " + id + ".");
            }else{
                alert("Roll borrado: " + id + ".");
            }
        }
    });
    leer(0);
}

function crear(){
    IdRoll = document.getElementById("id").value;
    nombreRoll = document.getElementById("descripcion").value;
    tipoRoll = document.getElementById("tipo").value;
    nivelRoll = document.getElementById("nivel").value;
    urltorequest = urlWS +"Roll/crear";
    $.ajax({
        type: "post",
        url: urltorequest,
        data:JSON.stringify({IdRoll: IdRoll, nombreRoll: nombreRoll,  tipoRoll: tipoRoll, nivelRoll: nivelRoll}),
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al crear el Roll");
            }else{
                alert("Roll creado.");
            }
        }
    });
    leer(0);
}

function actualizar(){
    id = document.getElementById("id").value;
    descripcion = document.getElementById("descripcion").value;
    urltorequest = urlWS +"Roll/actualizar";
    $.ajax({
        type: "post",
        url: urltorequest,
        data:JSON.stringify({id: id, descripcion: descripcion}),
        async:false,
        success:  function (respuesta) {
            if(respuesta=="false"){
                alert("Error al actualizar el Roll");
            }else{
                alert("Registro actualizado.");
            }
        }
    });
    leer(0);
}
