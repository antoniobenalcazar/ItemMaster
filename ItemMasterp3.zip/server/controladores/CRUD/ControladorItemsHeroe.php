<?php
include_once('../controladores/ControladorBase.php');
include_once('../entidades/CRUD/ItemsHeroe.php');
class ControladorItemsHeroe extends ControladorBase
{
   function crear(ItemsHeroe $itemsheroe)
   {
      $sql = "INSERT INTO ItemsHeroe (IdItemsHeroe,IdItem1,IdItem2,IdItem3,IdItem4,IdItem5,IdItem6) VALUES (?,?,?,?,?,?,?);";
      $parametros = array($itemsheroe->IdItemsHeroe,$itemsheroe->IdItem1,$itemsheroe->IdItem2,$itemsheroe->IdItem3,$itemsheroe->IdItem4,$itemsheroe->IdItem5,$itemsheroe->IdItem6);
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      if(is_null($respuesta[0])){
         return true;
      }else{
         return false;
      }
   }

   function actualizar(ItemsHeroe $itemsheroe)
   {
      $parametros = array($itemsheroe->IdItemsHeroe,$itemsheroe->IdItem1,$itemsheroe->IdItem2,$itemsheroe->IdItem3,$itemsheroe->IdItem4,$itemsheroe->IdItem5,$itemsheroe->IdItem6,$itemsheroe->id);
      $sql = "UPDATE ItemsHeroe SET IdItemsHeroe = ?,IdItem1 = ?,IdItem2 = ?,IdItem3 = ?,IdItem4 = ?,IdItem5 = ?,IdItem6 = ? WHERE id = ?;";
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      if(is_null($respuesta[0])){
         return true;
      }else{
         return false;
      }
   }

   function borrar(int $id)
   {
      $parametros = array($id);
      $sql = "DELETE FROM ItemsHeroe WHERE id = ?;";
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      if(is_null($respuesta[0])){
         return true;
      }else{
         return false;
      }
   }

   function leer($id)
   {
      if ($id==""){
         $sql = "SELECT * FROM ItemsHeroe;";
      }else{
      $parametros = array($id);
         $sql = "SELECT * FROM ItemsHeroe WHERE id = ?;";
      }
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      return $respuesta;
   }

   function leer_paginado($pagina,$registrosPorPagina)
   {
      $desde = (($pagina-1)*$registrosPorPagina);
      $sql ="SELECT * FROM ItemsHeroe LIMIT $desde,$registrosPorPagina;";
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      return $respuesta;
   }

   function numero_paginas($registrosPorPagina)
   {
      $sql ="SELECT IF(ceil(count(*)/$registrosPorPagina)>0,ceil(count(*)/$registrosPorPagina),1) as 'paginas' FROM ItemsHeroe;";
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      return $respuesta[0];
   }

   function leer_filtrado(string $nombreColumna, string $tipoFiltro, string $filtro)
   {
      switch ($tipoFiltro){
         case "coincide":
            $parametros = array($filtro);
            $sql = "SELECT * FROM ItemsHeroe WHERE $nombreColumna = ?;";
            break;
         case "inicia":
            $sql = "SELECT * FROM ItemsHeroe WHERE $nombreColumna LIKE '$filtro%';";
            break;
         case "termina":
            $sql = "SELECT * FROM ItemsHeroe WHERE $nombreColumna LIKE '%$filtro';";
            break;
         default:
            $sql = "SELECT * FROM ItemsHeroe WHERE $nombreColumna LIKE '%$filtro%';";
            break;
      }
      $respuesta = $this->conexion->ejecutarConsulta($sql,$parametros);
      return $respuesta;
   }
}