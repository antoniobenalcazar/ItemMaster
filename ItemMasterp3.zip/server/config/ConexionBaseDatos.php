<?php
include_once("../persistencia/DatosConexion.php");
class ConexionBaseDatos {
    private static $array = array();
    public static function DatosConexiones(){
        $array = array();
        $array[] = new DatosConexion("ItemMaster","localhost","ItemMaster","root","corazon321");
        $array[] = new DatosConexion("ItemMaster","sql304.byethost13.com","b13_21149095_ItemMaster","b13_21149095","Dralcatraz99@");
        return $array;
    }
}
