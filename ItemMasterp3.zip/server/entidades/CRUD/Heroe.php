<?php
class Heroe
{
   public $IdHeroe;
   public $nombreHeroe;
   public $IdTipoHeroe;
   public $IdRoll;
   public $IdItemsHeroe;

   function __construct($IdHeroe,$nombreHeroe,$IdTipoHeroe,$IdRoll,$IdItemsHeroe){
      $this->IdHeroe = $IdHeroe;
      $this->nombreHeroe = $nombreHeroe;
      $this->IdTipoHeroe = $IdTipoHeroe;
      $this->IdRoll = $IdRoll;
      $this->IdItemsHeroe = $IdItemsHeroe;
   }
}
?>