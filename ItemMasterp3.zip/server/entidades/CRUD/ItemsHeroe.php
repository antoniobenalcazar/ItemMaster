<?php
class ItemsHeroe
{
   public $IdItemsHeroe;
   public $IdItem1;
   public $IdItem2;
   public $IdItem3;
   public $IdItem4;
   public $IdItem5;
   public $IdItem6;

   function __construct($IdItemsHeroe,$IdItem1,$IdItem2,$IdItem3,$IdItem4,$IdItem5,$IdItem6){
      $this->IdItemsHeroe = $IdItemsHeroe;
      $this->IdItem1 = $IdItem1;
      $this->IdItem2 = $IdItem2;
      $this->IdItem3 = $IdItem3;
      $this->IdItem4 = $IdItem4;
      $this->IdItem5 = $IdItem5;
      $this->IdItem6 = $IdItem6;
   }
}
?>