<?php
class Roll
{
   public $IdRoll;
   public $nombreRoll;
   public $tipoRoll;
   public $nivelRoll;

   function __construct($IdRoll,$nombreRoll,$tipoRoll,$nivelRoll){
      $this->IdRoll = $IdRoll;
      $this->nombreRoll = $nombreRoll;
      $this->tipoRoll = $tipoRoll;
      $this->nivelRoll = $nivelRoll;
   }
}
?>