<?php
class Item
{
   public $IdItem;
   public $nombreItem;
   public $tipoItem;
   public $nivelItem;

   function __construct($IdItem,$nombreItem,$tipoItem,$nivelItem){
      $this->IdItem = $IdItem;
      $this->nombreItem = $nombreItem;
      $this->tipoItem = $tipoItem;
      $this->nivelItem = $nivelItem;
   }
}
?>