<?php
class Tipo
{
   public $IdTipo;
   public $nombreTipoHeroe;

   function __construct($IdTipo,$nombreTipoHeroe){
      $this->IdTipo = $IdTipo;
      $this->nombreTipoHeroe = $nombreTipoHeroe;
   }
}
?>